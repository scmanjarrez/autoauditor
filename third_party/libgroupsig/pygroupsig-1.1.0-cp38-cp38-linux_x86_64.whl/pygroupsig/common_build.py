# file "common_build.py"

from cffi import FFI
ffibuilder = FFI()

#
# SPDX-License-Identifier: Apache-2.0
#

from .version import VERSION  # noqa
